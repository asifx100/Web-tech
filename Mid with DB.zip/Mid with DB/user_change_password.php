<?php
session_start();
	if(isset($_SESSION["id"]) )
	{    
    	$id= $_SESSION["id"];

?>

<center>
	<form>
		<table border="0" cellspacing="0" cellpadding="5">
			<tr>
				<td>
					<fieldset>
						<legend>CHANGE PASSWORD</legend>
						Current Password<br />
						<input type="password" /><br />
						New Password<br />
						<input type="password" /><br />
						Retype New Password<br />
						<input type="password"/>								
						<hr />
						<input type="button" value="Change" />     
						<a href="user_home.php?id=$id&Type=User">Home</a>						
					</fieldset>
				</td>
			</tr>
		</table>
	</form>
</center>

<?php
   }
	else
	{
		echo "Please login first";
	}

?>