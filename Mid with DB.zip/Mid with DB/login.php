<?php
error_reporting(0);

session_start();
if(isset($_POST['id'])&&isset($_POST['password']))
{
//	$ifpassnotfound=0;
	$admin="admin";
	$user="user";
	$id=$_POST['id'];
	$pass=$_POST['password'];

$servername ="localhost";
    $username   ="root";
    $password   ="";
    $dbname     ="midlabexam";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if(!$conn){
        die("Connection Error!".mysqli_connect_error());
    }
    
    $sql = "select * from user";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result)>0){
        
        while($row=mysqli_fetch_assoc($result))
        {

            if ($id==$row['id']&&$pass==$row['pass']&&$admin==$row['type']) 
            {
                $_SESSION["id"] = $id;
                    $_SESSION["Type"] = $user;
                    header("Location: admin_home.php?id=$id&Type=$admin");

            }

            elseif ($id==$row['id']&&$pass==$row['pass']&&$user==$row['type']) 
            {
                $_SESSION["id"] = $id;
                    $_SESSION["Type"] = $user;
                    header("Location: user_home.php?id=$id&Type=$user");

            }
            else
            {
                //header("Location: login.php?ret=error");
                echo "User name or password didnot match</br>";    
            }
        }
        
    }else{
        echo "Result not found!";
    }
    mysqli_close($conn);

}

?>

<html>
<center>
<form action="#" method="POST" enctype="multipart/form-data" >
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
					<legend><h3>LOGIN</h3></legend>
					User Id<br/>
					<input name="id" type="text"><br/>                               
					Password<br/>
					<input name="password" type="password">
					<br /><hr/>
					<input type="submit" name="submit" value="Login">
					<a href="registration.php">Register</a>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>
</html>