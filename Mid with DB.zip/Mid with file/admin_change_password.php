<?php
session_start();
	if(isset($_SESSION["id"]) )
	{    
    	$id= $_SESSION["id"];
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
    	  $pass = test_input($_POST["password"]);
  		  $newpassword = test_input($_POST["newpassword"]);
  		  $newpassword = test_input($_POST["cnewpassword"]);
  		  $passok=0;

  		   /*$myfile = fopen("newfile.txt", "a") or die("Unable to open file!");
  		   $line = fgets($myfile);
  		   while(! feof($myfile))
  		   {
  		   		myarray = explode(':',$line); 
  		   		if($myarray[1]==$id)
  		   		{
  		   			if($myarray[3]==$pass)
  		   			{
  		   				jfs
  		   			}
  		   			else
  		   			{
  		   				echo "Old Password not found";
  		   			}
  		   		}
  		   		$line = fgets($myfile);
  		   }*/

    }

?>

<center>
	<form>
		<table border="0" cellspacing="0" cellpadding="5">
			<tr>
				<td>
					<fieldset>
						<legend>CHANGE PASSWORD</legend>
						Current Password<br />
						<inputn name="password" type="password" /><br />
						New Password<br />
						<input name="newpassword" type="newpassword" /><br />
						Retype New Password<br />
						<input name="cnewpassword" type="cnewpassword"/>								
						<hr />
						<input name="submit" type="submit" value="Change" />     
						<a href="admin_home.php?id=$id&Type=Admin">Home</a>						
					</fieldset>
				</td>
			</tr>
		</table>
	</form>
</center>

<?php
   }
	else
	{
		echo "Please login first";
	}


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>