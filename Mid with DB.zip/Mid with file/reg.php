<?php
error_reporting(0);


if ($_SERVER["REQUEST_METHOD"] == "POST") 
{

  $id = test_input($_POST["Id"]);
  $pass = test_input($_POST["password"]);
  $confirmpass = test_input($_POST["cpassword"]);
  $name = test_input($_POST["name"]);
  $idok=0;
  $nameok=0;
  $passok=0;
  $radiook=0;



  $myfile = fopen("newfile.txt", "a") or die("Unable to open file!");


  if (empty($id)) 
  {
   echo "Id is required";
 $idok=0;
  }
  elseif(!preg_match("/^[0-9-]*$/",$id))
  {
       echo "Id is not in number mode<br/>";
      $idok=0;
   }    
  else
  {
    $text ="ID:".$id.":";
  $idok=1;
  }  
 

  if (empty($pass)) 
  {
   echo "Password is required<br/>";
   $passok=0;
  } 
  elseif (strlen($pass)<8) {
    echo "Password length mustbe 8 character<br/>";
    $passok=0;
  }
  elseif($pass!==$confirmpass)
  {
    echo "Password did not match<br/>";
    $passok=0;
  }
  else
  {
     $text .="Password:".$pass.":";
      $passok=1;
  }  
 

  
  if (empty($name)) 
  {
   echo "Name is required<br/>";
    $nameok=0;
  } 
  elseif(!preg_match("/^[a-zA-Z ]*$/",$name))
  {
    echo "Only letters and white space allowed";
      $nameok=0;
  }
   
  else
  {
  if (str_word_count($name)<2)
  {
      echo "Name should contain 2 words<br/>";
        $nameok=0;
  }
  else{
    $text .="Name:".$name.":";
    $nameok=1;
  }
  }  
 

    if(isset($_POST['radio']))
    {

      if($_POST['radio']=="user")
        {
          $text .="Type:"."User".":"."\r\n";
            $radiook=1;

        }
      else
        {

         $text .="Type:"."Admin".":"."\r\n";
           $radiook=1;
  
        }
    }
    
  else
  {
    echo "Please select at least one<br/>";
      $radiook=0;
  }
  if ($idok==1 && $nameok==1 && $passok==1 && $radiook==1) 
  {
    fwrite($myfile, $text);
    fclose($myfile);
    echo "submitted,goto login\n";
  }
  
  
}










function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


?>