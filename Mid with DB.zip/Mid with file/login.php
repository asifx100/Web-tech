<?php
error_reporting(0);

session_start();
if(isset($_POST['id'])&&isset($_POST['password']))
{
	$ifpassnotfound=0;
	$admin="Admin";
	$user="User";
	$id=$_POST['id'];
	$pass=$_POST['password'];

	$myfile = fopen("newfile.txt", "r") or die("Unable to open file!");
	$line = fgets($myfile);
	while(! feof($myfile))
	{
		$myarray = explode(':',$line); 
		if($myarray[1]==$id)
		{
			if($myarray[3]==$pass)
			{
				if ($myarray[7]==$user) 
				{
					$_SESSION["id"] = $id;
					$_SESSION["Type"] = $user;
					header("Location: user_home.php?id=$id&Type=$user");
				}
				elseif($myarray[7]==$admin)
				{
					$_SESSION["id"] = $id;
					$_SESSION["Type"] = $admin;
					header("Location: admin_home.php?id=$id&Type=$admin");
				}
				
			}
			else
			{
				$ifpassnotfound=1;
			}
			break;
		}
	   
		$line = fgets($myfile);
	}

	if ($ifpassnotfound==1) 
			echo "Password not matched";
	else	
		  	echo "Id not found";
		
	
	fclose($myfile);

}

?>

<html>
<center>
<form action="#" method="POST" enctype="multipart/form-data" >
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
					<legend><h3>LOGIN</h3></legend>
					User Id<br/>
					<input name="id" type="text"><br/>                               
					Password<br/>
					<input name="password" type="password">
					<br /><hr/>
					<input type="submit" name="submit" value="Login">
					<a href="registration.php">Register</a>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>
</html>